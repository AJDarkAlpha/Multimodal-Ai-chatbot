css ="""
    <style>
        /* User Chat Message */

        .st-emotion-cache-janbn0 {
            background-color: #2b313e;
        }

        /* AI Chat Message */
    
        .st-emotion-cache-4oy321 {
            background-color: #475063;
        }

        section[data-testid="stSidebar"] {
            width: 380px !important;
        }
    </style>
    """